BATTLE ZONE — Mobile 3D Prototype v0.1

WHAT THIS IS
A small, original browser-playable 3D third-person shooting prototype. It has a training island, touch movement joystick, camera drag, shooting, bots, ammo/reload, health and eliminations.

IMPORTANT LIMITATIONS
- This is a prototype, not a finished Free Fire-scale game.
- It is currently offline single-player with AI bots. Online multiplayer/server networking is not included yet.
- Requires internet to load Three.js from jsDelivr CDN.
- Android performance depends on the phone and browser.

HOW TO PLAY ON ANDROID (NO COMPUTER)
1. Extract battle_zone.zip using your phone's Files app or ZArchiver.
2. Easiest public demo: create a GitHub repository named battle-zone, upload index.html, then open repository Settings > Pages and choose Deploy from a branch, branch main, folder /(root), Save. Wait for GitHub Pages to publish; open the URL it gives you in Chrome.
3. You can also use an online HTML editor that supports module scripts, but GitHub Pages is recommended.
4. Tap DROP INTO TRAINING. Left joystick moves; drag on the right side to rotate camera; FIRE shoots; RELOAD refills ammo.

GITHUB UPLOAD
- Upload index.html to the repository root. README.txt is optional.
- No build step is needed; this is a static website.

NEXT DEVELOPMENT MILESTONES
1. Better animations, sound, weapon switching and optimized art.
2. Main menu, settings and save data.
3. Online rooms/multiplayer with authoritative server, matchmaking and anti-cheat. This requires additional engineering and a hosted backend; free-tier limits apply.
